#Jaicee Ball
#11/8/24
#P4LAB1a
#Draw a square and triangle using a for loop and turtle graphics

import turtle             
win = turtle.Screen()      
t = turtle.Turtle() 

#Pen settings
t.pensize(4)            
t.pencolor("red")    
t.shape("turtle")

#Draw a square
for _ in range(4):
    t.forward(100)  
    t.right(90)     

#Move the pen to a new position to draw the triangle
t.penup()
t.goto(-200, 0)
t.pendown()

#Draw a triangle
for _ in range(3):
    t.forward(100)  
    t.left(120)     

#End Command
win.mainloop()
