#Jaicee Ball
#11/8/24
#P4LAB1b
#Drawing my initials using turtle graphics

import turtle             
win = turtle.Screen()      
t = turtle.Turtle() 

#Pen settings
t.pensize(4)            
t.pencolor("red")    
t.shape("turtle")


#Draw the letter J
t.penup()
t.goto(-100, 0)
t.pendown()
t.forward(50)     
t.backward(25)    
t.right(90)
t.forward(100)   
t.right(90)
t.forward(25)

#Move the pen for the second Initial
t.penup()
t.goto(0, -100) 
t.setheading(90)  
t.pendown()

#Draw the letter B
t.forward(100)
t.right(90)
t.circle(-25, 180)
t.right(180)
t.circle(-25, 180)

#End Command
win.mainloop()
